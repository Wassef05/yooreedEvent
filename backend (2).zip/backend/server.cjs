require = require('esm')(module /*, options*/);
module.exports = require('./dist/server.js');

